<?php

return [
    'crypto' => 'Crypto (CoinPayments)',
    'search' => 'Search User',
    'openConversation' => 'Open a conversation by selecting an user',
    'setPrice' => 'Set Price',
    'setFree' => 'Cancel',
    'contact-us' => 'Send Inquiry',
    'posts' => 'Posts',
    'transferDetails' => 'Transfer details',
    'ifTransfer' => 'Crypto address + coin if Crypto',
    'update' => 'Update',
    'processingUpload' => 'Processing upload..'
];