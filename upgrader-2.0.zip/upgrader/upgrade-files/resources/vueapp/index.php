<?php // silence is golden
header('HTTP/1.0 403 Forbidden');
echo 'HTTP/1.0 403 Forbidden';
